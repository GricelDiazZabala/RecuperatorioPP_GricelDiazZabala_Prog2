
package recuperatorioppexpediciones;

import java.util.ArrayList;
import java.util.List;

public class AgenciaEspacial {
    
    String nombre;
    Nave nave;
    private List<Nave> naves = new ArrayList<>();
    public AgenciaEspacial(String nombre) {
        this.nombre = nombre;
    }
    
    public void agregarNave(Nave nave) throws NaveRepetidaException {
        if (naves.contains(nave)) {
            throw new NaveRepetidaException();
        }
        naves.add(nave);
        System.out.println("Nave agregada: " + nave);
    }

    
    public void mostrarNaves() {
        for (Nave nave : naves) {
            nave.mostrarInfo();
        }
    }
    
    public void explorar() {
        for (Nave nave : naves) {
            if (nave instanceof Explorable) {
                ((Explorable) nave).explorar();
            } else {
                System.out.println(nave.nombre + " no puede explorar");
            }
        }
    }
}
