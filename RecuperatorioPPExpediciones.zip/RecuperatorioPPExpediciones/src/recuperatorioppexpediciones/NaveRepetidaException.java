
package recuperatorioppexpediciones;


public class NaveRepetidaException extends RuntimeException {

    private final static String MESSAGE = "La nave ya está cargada en el sistema";
    
    public NaveRepetidaException() {
        super(MESSAGE);
    }


}