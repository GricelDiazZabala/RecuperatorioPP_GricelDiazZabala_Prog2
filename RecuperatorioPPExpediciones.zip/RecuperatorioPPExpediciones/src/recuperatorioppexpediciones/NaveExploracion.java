
package recuperatorioppexpediciones;

public class NaveExploracion extends Nave implements Explorable {
    
    private Misiones mision;

    public NaveExploracion(Misiones mision, String nombre, String anioLanzamiento, int capacidadTripulacion) {
        super(nombre, anioLanzamiento, capacidadTripulacion);
        this.mision = mision;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("NAVE DE EXPLORACION [" + "MISION: " + mision +  "AÑO DE LANZAMENTO" + anioLanzamiento + "CAPACIDAD DE TRIPULACION" + capacidadTripulacion + "]");
    }
    
    @Override
    public boolean explorable() {
        return true; 
    }

    @Override
    public void explorar() {
        System.out.println(nombre + " está explorando");
    }
    
}
