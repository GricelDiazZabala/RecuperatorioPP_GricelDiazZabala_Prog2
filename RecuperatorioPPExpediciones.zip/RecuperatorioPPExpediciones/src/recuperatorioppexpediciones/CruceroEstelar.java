
package recuperatorioppexpediciones;

public class CruceroEstelar extends Nave{
    
    private int capacidadPasajeros;

    public CruceroEstelar(int capacidadPasajeros, String nombre, String anioLanzamiento, int capacidadTripulacion) {
        super(nombre, anioLanzamiento, capacidadTripulacion);
        this.capacidadPasajeros = capacidadPasajeros;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("CRUCERO ESTELAR[" + "CAPACIDAD DE PASAJEROS: " + capacidadPasajeros +  " AÑO DE LANZAMENTO:" + anioLanzamiento + " CAPACIDAD DE TRIPULACION:" + capacidadTripulacion + "]");
    }
    
    
    
}
