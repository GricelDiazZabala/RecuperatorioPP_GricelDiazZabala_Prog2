
package recuperatorioppexpediciones;

public enum Misiones {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
