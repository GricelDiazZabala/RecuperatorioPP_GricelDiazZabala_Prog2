
package recuperatorioppexpediciones;

public abstract class Nave {
    
    protected String nombre;
    protected String anioLanzamiento; //acá lo uso como String en lugar de int porque en el programa no es necesario usarlo como int
    protected int capacidadTripulacion;

    public Nave(String nombre, String anioLanzamiento, int capacidadTripulacion) {
        this.nombre = nombre;
        this.anioLanzamiento = anioLanzamiento;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public boolean explorable() {
        return false;
    }
        
    public abstract void mostrarInfo();
    
    
    public String getNombre() {
        return nombre;
    }
    
    @Override
    public boolean equals(Object obj){
        if (this == obj){
            return true;
        }
        if (obj == null){
            return false;
        }
        if (obj instanceof Nave other){
            return nombre.equals(other.nombre) && anioLanzamiento.equals(other.anioLanzamiento);   
        }
        return false;
    }
    
    /*
    @Override
    public int hashCode(){
        return Objects.hash(nombre, anioLanzamiento);
    }
    */
}


