
package recuperatorioppexpediciones;

public class TestRecuperatorioPPExpediciones {

    public static void main(String[] args) {

        
        AgenciaEspacial agencia1 = new AgenciaEspacial("Espacio profundo 9");
        
        Carguero carguero1 = new Carguero(300, "Galáctica", "2019", 5000);
        agencia1.agregarNave(carguero1);   
        /*
        Para tirar la excepcion contralada, ejecutar lo siguiente
        Carguero prueba = new Carguero (500, "Galáctica", "2019", 200);
        agencia1.agregarNave(prueba);
        acá tira la excepcion de nave repetida
        */
        
        NaveExploracion naveExploracion1 = new NaveExploracion(Misiones.CONTACTO, "USS ENTERPRISE", "2078", 400);
        CruceroEstelar crucero1 = new CruceroEstelar(1000, "USS VOYAGER", "3100", 300);

        agencia1.agregarNave(naveExploracion1);
        agencia1.agregarNave(crucero1);
        
        System.out.println("Información de las naves: ");
        agencia1.mostrarNaves();

        System.out.println("\nNaves explorando: ");
        agencia1.explorar();
    
        
    }
        
    }
    

