
package recuperatorioppexpediciones;


public interface Explorable {
    
    void explorar();
}
