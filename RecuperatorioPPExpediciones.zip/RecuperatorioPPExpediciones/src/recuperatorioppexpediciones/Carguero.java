
package recuperatorioppexpediciones;


public class Carguero extends Nave implements Explorable{
    
    private int capacidadCarga;

    public Carguero(int capacidadCarga, String nombre, String anioLanzamiento, int capacidadTripulacion) {
        super(nombre, anioLanzamiento, capacidadTripulacion);
        this.capacidadCarga = capacidadCarga;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("CARGUERO [" + "CAPACIDAD DE CARGA: " + capacidadCarga +  " AÑO DE LANZAMENTO:" + anioLanzamiento + " CAPACIDAD DE TRIPULACION" + capacidadTripulacion + "]");
    }
    
    @Override
    public boolean explorable() {
        return true; 
    }

    @Override
    public void explorar() {
        System.out.println(nombre + " está explorando");
    }
}
